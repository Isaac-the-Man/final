Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Tesabob2001 ( https://freesound.org/people/Tesabob2001/ )

You can find this pack online at: https://freesound.org/people/Tesabob2001/packs/12995/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 203502__tesabob2001__a-3.mp3
    * url: https://freesound.org/s/203502/
    * license: Creative Commons 0
  * 203501__tesabob2001__f-3.mp3
    * url: https://freesound.org/s/203501/
    * license: Creative Commons 0
  * 203500__tesabob2001__f-4.mp3
    * url: https://freesound.org/s/203500/
    * license: Creative Commons 0
  * 203499__tesabob2001__f-5.mp3
    * url: https://freesound.org/s/203499/
    * license: Creative Commons 0
  * 203495__tesabob2001__g5.mp3
    * url: https://freesound.org/s/203495/
    * license: Creative Commons 0
  * 203494__tesabob2001__piano-chromatic-scale.mp3
    * url: https://freesound.org/s/203494/
    * license: Creative Commons 0
  * 203493__tesabob2001__g3.mp3
    * url: https://freesound.org/s/203493/
    * license: Creative Commons 0
  * 203492__tesabob2001__g4.mp3
    * url: https://freesound.org/s/203492/
    * license: Creative Commons 0
  * 203491__tesabob2001__g-4.mp3
    * url: https://freesound.org/s/203491/
    * license: Creative Commons 0
  * 203490__tesabob2001__g-5.mp3
    * url: https://freesound.org/s/203490/
    * license: Creative Commons 0
  * 203489__tesabob2001__f5.mp3
    * url: https://freesound.org/s/203489/
    * license: Creative Commons 0
  * 203488__tesabob2001__g-3.mp3
    * url: https://freesound.org/s/203488/
    * license: Creative Commons 0
  * 203487__tesabob2001__d-5.mp3
    * url: https://freesound.org/s/203487/
    * license: Creative Commons 0
  * 203486__tesabob2001__d3.mp3
    * url: https://freesound.org/s/203486/
    * license: Creative Commons 0
  * 203485__tesabob2001__c5.mp3
    * url: https://freesound.org/s/203485/
    * license: Creative Commons 0
  * 203484__tesabob2001__c6.mp3
    * url: https://freesound.org/s/203484/
    * license: Creative Commons 0
  * 203483__tesabob2001__d-3.mp3
    * url: https://freesound.org/s/203483/
    * license: Creative Commons 0
  * 203482__tesabob2001__d-4.mp3
    * url: https://freesound.org/s/203482/
    * license: Creative Commons 0
  * 203481__tesabob2001__c-4.mp3
    * url: https://freesound.org/s/203481/
    * license: Creative Commons 0
  * 203480__tesabob2001__c-5.mp3
    * url: https://freesound.org/s/203480/
    * license: Creative Commons 0
  * 203479__tesabob2001__c3.mp3
    * url: https://freesound.org/s/203479/
    * license: Creative Commons 0
  * 203478__tesabob2001__c4-middle-c.mp3
    * url: https://freesound.org/s/203478/
    * license: Creative Commons 0
  * 203477__tesabob2001__f-3.mp3
    * url: https://freesound.org/s/203477/
    * license: Creative Commons 0
  * 203476__tesabob2001__e5.mp3
    * url: https://freesound.org/s/203476/
    * license: Creative Commons 0
  * 203475__tesabob2001__f-5.mp3
    * url: https://freesound.org/s/203475/
    * license: Creative Commons 0
  * 203474__tesabob2001__f-4.mp3
    * url: https://freesound.org/s/203474/
    * license: Creative Commons 0
  * 203473__tesabob2001__d5.mp3
    * url: https://freesound.org/s/203473/
    * license: Creative Commons 0
  * 203472__tesabob2001__d4.mp3
    * url: https://freesound.org/s/203472/
    * license: Creative Commons 0
  * 203471__tesabob2001__e4.mp3
    * url: https://freesound.org/s/203471/
    * license: Creative Commons 0
  * 203470__tesabob2001__e3.mp3
    * url: https://freesound.org/s/203470/
    * license: Creative Commons 0
  * 203469__tesabob2001__f4.mp3
    * url: https://freesound.org/s/203469/
    * license: Creative Commons 0
  * 203468__tesabob2001__f3.mp3
    * url: https://freesound.org/s/203468/
    * license: Creative Commons 0
  * 203467__tesabob2001__b5.mp3
    * url: https://freesound.org/s/203467/
    * license: Creative Commons 0
  * 203466__tesabob2001__c-3.mp3
    * url: https://freesound.org/s/203466/
    * license: Creative Commons 0
  * 203465__tesabob2001__a4.mp3
    * url: https://freesound.org/s/203465/
    * license: Creative Commons 0
  * 203464__tesabob2001__a5.mp3
    * url: https://freesound.org/s/203464/
    * license: Creative Commons 0
  * 203463__tesabob2001__b3.mp3
    * url: https://freesound.org/s/203463/
    * license: Creative Commons 0
  * 203462__tesabob2001__b4.mp3
    * url: https://freesound.org/s/203462/
    * license: Creative Commons 0
  * 203461__tesabob2001__a-3.mp3
    * url: https://freesound.org/s/203461/
    * license: Creative Commons 0
  * 203460__tesabob2001__a-4.mp3
    * url: https://freesound.org/s/203460/
    * license: Creative Commons 0
  * 203459__tesabob2001__a-5.mp3
    * url: https://freesound.org/s/203459/
    * license: Creative Commons 0
  * 203458__tesabob2001__a3.mp3
    * url: https://freesound.org/s/203458/
    * license: Creative Commons 0


